import parser
import string
import random
import os

output_file = None

def id_generator(size=6, chars=string.ascii_uppercase + string.ascii_lowercase):
    return ''.join(random.choice(chars) for _ in range(size))


def select_lbl(lbl: str):
    return f'@{lbl}\n'

def dec_lbl(lbl: str):
    return f'({lbl})\n'

def select_top_stack():
    assem = (
        "@SP\n"
        "A=M-1\n"
    )
    return assem

def pop_stack_to_D():
    assem = (
        "@SP\n"
        "M=M-1\n"
        "A=M\n"
        "D=M\n"
    )
    return assem

def push_D_to_stack():
    assem = (
        "@SP\n"
        "A=M\n"
        "M=D\n"
        "@SP\n"
        "M=M+1\n"
    )
    return assem

def set_top_stack(operation: str):
    assem = (
        f'{select_top_stack()}'
        f'M={operation}\n'
    )
    return assem


def unary_assem(operation: str):
    return set_top_stack(operation)

def binary_assem(operation: str):
    return pop_stack_to_D() + unary_assem(operation)

def goto(lbl: str, variable: str='0', oper:str='JMP'):
    return (
        f"{select_lbl(lbl)}"
        f"{variable};{oper}\n"
    )


def assign(dest, value):
    return f'{dest}={value}\n'

def select_symbol(symbol: str):
    return f'@{symbol}\n'

def assign_symbol(dest: str, symbol: str):
    return (
        f"{select_symbol(symbol)}"
        f"{dest}=A\n"
    )

def assign_symbol_val(dest: str, symbol: str):
    return (
        f"@{symbol}\n"
        f"{dest}=M\n"
    )

def compare_assembly(oper: str):
    id = id_generator(10)
    lbl = f"{oper}_{id}_lbl"
    end_lbl = f'{lbl}_end'

    assem = (
        pop_stack_to_D() +
        select_top_stack() +
        assign("D", "M-D") +

        goto(lbl, "D", oper) +

        set_top_stack("0") +
        goto(end_lbl) +

        dec_lbl(lbl) +
        set_top_stack("-1") +
        dec_lbl(end_lbl)
    )
    return assem


def push_constant(i: str):
    return assign_symbol("D", i) + push_D_to_stack()


def push_from_D_base(i: str):
    return (
        select_symbol(i) +
        assign("A", "D+A") + 
        assign("D", "M") +
        push_D_to_stack()
    )

def pop_to_D_base(i: str):
    return (
        select_symbol(i) +
        assign("D", "D+A") +
        select_symbol("R13") +
        assign("M", "D") +
        pop_stack_to_D() +
        select_symbol("R13") +
        assign("A", "M") +
        assign("M", "D"))


def push_from_base_pointer(seg_base: str, i: str):
    return ( assign_symbol_val("D", seg_base) + 
              push_from_D_base(i)
            )

def pop_to_base_pointer(seg_base: str, i: str):
    return (
        assign_symbol_val("D", seg_base) + 
        pop_to_D_base(i)
    )

def push_from_base(seg_base: str, i: str):
    return ( assign_symbol("D", seg_base) + 
              push_from_D_base(i)
            )

def pop_to_base(seg_base: str, i: str):
    return (
        assign_symbol("D", seg_base) + 
        pop_to_D_base(i)
    )

def push_static(classname: str, i: str):
    return (
        assign_symbol_val("D", f"{classname}.{i}") +
        push_D_to_stack()
    )

def assign_to_symbol(symbol, value):
    return (select_symbol(symbol) + f"M={value}\n")

def pop_static(classname: str, i: str):
    assem = (
        pop_stack_to_D() +
        assign_to_symbol(f"{classname}.{i}", "D")
    )
    return assem

def end_loop():
    return dec_lbl("final_end") + goto("final_end")

ArithmeticTable = {
    "add": lambda: binary_assem("D+M"),
    "sub": lambda: binary_assem("M-D"),
    "neg": lambda: unary_assem("-M"),
    "eq": lambda: compare_assembly("JEQ"),
    "gt": lambda: compare_assembly("JGT"),
    "lt": lambda: compare_assembly("JLT"),
    "and": lambda: binary_assem("D&M"),
    "or": lambda: binary_assem("D|M"),
    "not": lambda: unary_assem("!M")
}

PushTable = {
    "local": lambda index: push_from_base_pointer("LCL", index),
    "argument": lambda index: push_from_base_pointer("ARG", index),
    "this": lambda index: push_from_base_pointer("THIS", index),
    "that": lambda index: push_from_base_pointer("THAT", index),
    "constant": lambda value: push_constant(value),
    "static": lambda outfile, index: push_static(outfile, index),
    "pointer": lambda index: push_from_base("3", index),
    "temp": lambda index: push_from_base("5", index)
}

PopTable = {
    "local": lambda index: pop_to_base_pointer("LCL", index),
    "argument": lambda index: pop_to_base_pointer("ARG", index),
    "this": lambda index: pop_to_base_pointer("THIS", index),
    "that": lambda index: pop_to_base_pointer("THAT", index),
    "static": lambda outfile, index: pop_static(outfile, index),
    "pointer": lambda index: pop_to_base("3", index),
    "temp": lambda index: pop_to_base("5", index)
}

class CodeWriter:
    def __init__(self, out_stream) -> None:
        self.out_file = out_stream
        self.fp = open(self.out_file, "w")
    
    def write_arithematic(self, command: str):
        assembly_func = ArithmeticTable.get(command)
        if assembly_func is None:
            raise Exception("Invalid value")
        assembly = assembly_func()
        self.fp.write(assembly)
    
    def WritePushPop(self, command, segment, index):
        assem = ""
        index = str(index)
        if command == parser.C_PUSH:
            if pushfn := PushTable.get(segment):
                if segment == "static":
                    classname = os.path.basename(self.out_file).split('.')[0]
                    assem = pushfn(classname, index)
                else:
                    assem = pushfn(index)
            else:
                raise Exception("invalid value")
        elif command == parser.C_POP:
            if popfn := PopTable.get(segment):
                if segment == "static":
                    classname = os.path.basename(self.out_file).split('.')[0]
                    assem = popfn(classname, index)
                else:
                    assem = popfn(index)
            else:
                raise Exception("invalid value")
        self.fp.write(assem)
    
    def WriteEndloop(self):
        assam = end_loop()
        self.fp.write(assam)

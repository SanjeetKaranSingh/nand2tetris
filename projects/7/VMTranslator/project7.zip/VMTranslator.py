#!/usr/bin/env python3
import sys
import parser
from parser import Parser
from code_writer import CodeWriter

def main():
    args = sys.argv
    if len(args) < 2:
        print("Error missing input")
        return 1
    
    input_file = args[1]
    if (not input_file.endswith(".vm")):
        print("Invalid file")
        return 1
    
    output_file = input_file.split('.')[0] + ".asm"

    m_parser = Parser(input_file)
    m_codeWriter = CodeWriter(output_file)

    for instruction in m_parser.iter_each_instruction():
        if (instruction.type == parser.C_PUSH or 
            instruction.type == parser.C_POP):
            m_codeWriter.WritePushPop(instruction.type, instruction.arg1, instruction.arg2)
        elif (instruction.type == parser.C_ARITHMETIC):
            m_codeWriter.write_arithematic(instruction.arg1)
    m_codeWriter.WriteEndloop()
main()